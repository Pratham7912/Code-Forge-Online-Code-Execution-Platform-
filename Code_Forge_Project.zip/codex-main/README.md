# Code Forge - Online Code Execution Platform

A web-based code execution platform that lets users write and run programs in Python, C++, and Java, with an integrated Gemini AI coding assistant.

## Features

- **Multi-language Code Execution**: Run Python, C++, and Java code using the Piston API.
- **Real-time Execution Workflow**: Submit code and custom input, then view execution output or errors in the results panel.
- **Gemini AI Assistant**: Get AI-powered help with code debugging, code generation, and code explanations.
- **Error Handling**: Display execution and request errors to help users understand failed runs.
- **Responsive Interface**: Use the coding workspace across desktop and mobile screen sizes.

## Technology Stack

- **Frontend**: Next.js, React, TypeScript, Monaco Editor
- **Backend**: Next.js API Routes
- **Code Execution**: Piston API
- **AI Assistant**: Google Gemini API
- **Styling**: Tailwind CSS

## Getting Started

### Prerequisites

- Node.js
- npm

### Installation

1. Install dependencies:
   ```bash
   npm install
   ```

2. Configure the environment variables required by the code execution endpoint and Gemini assistant in your `.env.local` file.

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open `http://localhost:3000` in your browser.

## Usage

1. Select Python, C++, or Java from the language dropdown.
2. Write your code in the editor.
3. Add any required standard input.
4. Select **Run Code** to submit the program for execution through the Piston API.
5. Review the output or error message in the results panel.
6. Open the Gemini-powered coding assistant to ask for debugging help, code generation, or explanations.

## APIs

- **Piston API** handles code execution.
- **Google Gemini API** powers AI coding assistance.
